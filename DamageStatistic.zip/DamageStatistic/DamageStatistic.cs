﻿using System;
using System.Collections.Generic;
using System.Linq;
using Terraria;
using TerrariaApi.Server;
using TShockAPI;

namespace DamageStatistic
{
    [ApiVersion(2, 1)]
    public class DamageStatistic : TerrariaPlugin
    {
        public override string Name => "DamageStatistic-伤害统计";
        public override Version Version => new Version(1, 0);
        public override string Author => "Megghy";
        public override string Description => "Show the damage caused by each player after each boss battle";
        public DamageStatistic(Main game) : base(game)
        {

        }
        public override void Initialize()
        {
            ServerApi.Hooks.NpcSpawn.Register(this, OnNpcSpawn);
            ServerApi.Hooks.NpcStrike.Register(this, OnStrike);
            ServerApi.Hooks.NpcKilled.Register(this, OnNpcKill);
        }


        private Dictionary<NPC, Dictionary<string, double>> damageList = new Dictionary<NPC, Dictionary<string, double>>();

        private void OnNpcSpawn(NpcSpawnEventArgs args)
        {
            NPC npc = Main.npc[args.NpcId];
            if (npc.boss) damageList.Add(npc,new Dictionary<string, double>());
        }

        private void OnStrike(NpcStrikeEventArgs args)
        {
            if (damageList.ContainsKey(args.Npc))
            {
                string player = args.Player.name;
                int damage = args.Damage;
                if (damageList[args.Npc].ContainsKey(player))
                {
                    damageList[args.Npc][player] = damageList[args.Npc][player] + damage;
                }
                else
                {
                    damageList[args.Npc].Add(player, damage);
                }
            }
        }

        private void OnNpcKill(NpcKilledEventArgs args)
        {
            if (damageList.ContainsKey(args.npc))
            {
                if (damageList[args.npc].Any())
                {
                    double npclifemax = 0;
                    string list = null;
                    List<string> playerlist = new List<string>();
                    foreach (string playername in damageList[args.npc].Keys)
                    {
                        npclifemax += damageList[args.npc][playername];
                        playerlist.Add(playername);
                    }
                    playerlist.Sort();
                    playerlist.Reverse();
                    foreach (string playername in playerlist)
                    {
                        list += $"{playername}: [c/74F3C9:{damageList[args.npc][playername]}] <{damageList[args.npc][playername] / npclifemax:0.00%}>, ";
                    }
                    string text = $"[c/74F3C9:{damageList[args.npc].Count}] 位玩家击败了 [c/74F3C9:{args.npc.FullName}]\n{list}";
                    TShock.Utils.Broadcast(text, (byte)247, (byte)244, (byte)150);
                    damageList.Remove(args.npc);
                }
            }
        }
    }
}
